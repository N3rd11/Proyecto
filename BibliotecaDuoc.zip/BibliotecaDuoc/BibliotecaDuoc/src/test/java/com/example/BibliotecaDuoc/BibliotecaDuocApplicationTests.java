package com.example.BibliotecaDuoc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaDuocApplicationTests {

	@Test
	void contextLoads() {
	}

}
