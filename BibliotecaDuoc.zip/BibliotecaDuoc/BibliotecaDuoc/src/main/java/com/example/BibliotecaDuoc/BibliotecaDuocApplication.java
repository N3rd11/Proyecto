package com.example.BibliotecaDuoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecaDuocApplication {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecaDuocApplication.class, args);
	}

}
